import zipfile

#服务器中imangnet-100的数据处理
TRAIN_SRC_DIR = '/root/autodl-pub/ImageNet100/imagenet100.zip'
TRAIN_DEST_DIR = '/root/autodl-tmp/imagenet/train'


def extract_train():
    file = zipfile.ZipFile(TRAIN_SRC_DIR, "r")
    for fileName in file.namelist():
        file.extract(fileName, TRAIN_DEST_DIR)

extract_train()
