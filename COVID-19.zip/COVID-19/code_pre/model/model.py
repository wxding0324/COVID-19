import torch
import torch.nn as nn


#base_model 的搭建

#3x3conv+bn+relu
class conv3x3(nn.Module):
    def __init__(self, in_planes, out_channels, stride=1, padding=0):
        super(conv3x3, self).__init__()
        self.conv3x3 = nn.Sequential(
            nn.Conv2d(in_planes, out_channels, kernel_size=3, stride=stride, padding=padding),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )

    def forward(self, input):
        return self.conv3x3(input)

#1x1conv+BN+relu
class conv1x1(nn.Module):
    def __init__(self, in_planes, out_channels, stride=1, padding=0):
        super(conv1x1, self).__init__()
        self.conv1x1 = nn.Sequential(
            nn.Conv2d(in_planes, out_channels, kernel_size=1, stride=stride, padding=padding),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )

    def forward(self, input):
        return self.conv1x1(input)


class stem(nn.Module):
    def __init__(self, in_planes=3):
        super(stem, self).__init__()

        self.conv1 = conv3x3(in_planes=in_planes, out_channels=32, stride=2, padding=0)
        self.conv2 = conv3x3(in_planes=32, out_channels=32, stride=1, padding=0)
        self.conv3 = conv3x3(in_planes=32, out_channels=64, stride=1, padding=1)
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=0)
        self.conv4 = conv3x3(in_planes=64, out_channels=96, stride=2, padding=0)

        self.conv5 = conv1x1(in_planes=160, out_channels=64, stride=1, padding=1)
        self.conv6 = conv3x3(64, 96, 1, 0)
        self.conv7 = conv1x1(160, 64, 1, 1)
        self.conv8 = nn.Conv2d(in_channels=64, out_channels=64, stride=1, kernel_size=(7, 1), padding=(3, 0))
        self.conv9 = nn.Conv2d(in_channels=64, out_channels=64, stride=1, kernel_size=(1, 7), padding=(0, 3))
        self.conv10 = conv3x3(64, 96, 1, 0)

        self.conv11 = conv3x3(192, 192, 2, 0)
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=0)

        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x1 = self.maxpool1(x)
        x2 = self.conv4(x)
        x = torch.cat([x1, x2], dim=1)

        x1 = self.conv5(x)
        x1 = self.conv6(x1)
        x2 = self.conv7(x)
        x2 = self.conv8(x2)
        x2 = self.relu(x2)
        x2 = self.conv9(x2)
        x2 = self.relu(x2)
        x2 = self.conv10(x2)
        x = torch.cat([x1, x2], dim=1)

        x1 = self.conv11(x)
        x2 = self.maxpool2(x)
        x = torch.cat([x1, x2], dim=1)
        return x


class block0(nn.Module):
    def __init__(self, input, scale=0.3):
        super(block0, self).__init__()
        self.conv1 = conv1x1(in_planes=input, out_channels=32, stride=1, padding=0)

        self.conv2 = conv1x1(in_planes=input, out_channels=32, stride=1, padding=0)
        self.conv3 = conv3x3(32, 32, 1, 1)

        self.conv4 = conv1x1(in_planes=input, out_channels=32, stride=1, padding=0)
        self.conv5 = conv3x3(32, 48, 1, 1)
        self.conv6 = conv3x3(48, 64, 1, 1)

        self.linear = nn.Conv2d(128, 384, 1, stride=1, padding=0, bias=True)
        self.scale = scale

        self.relu = nn.ReLU()

    def forward(self, x):
        x1 = self.conv1(x)

        x2 = self.conv2(x)
        x2 = self.conv3(x2)

        x3 = self.conv4(x)
        x3 = self.conv5(x3)
        x3 = self.conv6(x3)

        cat = torch.cat([x1, x2, x3], dim=1)

        linear = self.linear(cat)

        out = self.scale*x + linear
        out = self.relu(out)
        return out


class Redution_0(nn.Module):
    def __init__(self, input, n=384, k=256, l=256, m=384):
        super(Redution_0, self).__init__()

        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=0)

        self.conv1 = conv3x3(in_planes=input, out_channels=n, stride=2, padding=0)

        self.conv2 = conv1x1(in_planes=input, out_channels=k, stride=1, padding=1)
        self.conv3 = conv3x3(in_planes=k, out_channels=l, stride=1, padding=0)
        self.conv4 = conv3x3(in_planes=l, out_channels=m, stride=2, padding=0)

    def forward(self, x):
        c1 = self.maxpool(x)

        c2 = self.conv1(x)

        c3 = self.conv2(x)
        c3 = self.conv3(c3)
        c3 = self.conv4(c3)

        cat = torch.cat([c1, c2, c3], dim=1)

        return cat


class block1(nn.Module):
    def __init__(self, input, scale=0.3):
        super(block1, self).__init__()
        self.conv1 = conv1x1(in_planes=input, out_channels=192, stride=1, padding=1)

        self.conv2 = conv1x1(in_planes=input, out_channels=128, stride=1, padding=1)
        self.conv1x7 = nn.Conv2d(in_channels=128, out_channels=160, kernel_size=(1, 7), padding=(0, 3))
        self.conv7x1 = nn.Conv2d(in_channels=160, out_channels=192, kernel_size=(7, 1), padding=(3, 0))

        self.linear = nn.Conv2d(384, 1152, 1, stride=1, padding=0, bias=True)
        self.scale = scale

        self.relu = nn.ReLU()

    def forward(self, x):
        c1 = self.conv1(x)

        c2 = self.conv2(x)
        c2 = self.conv1x7(c2)
        c2 = self.relu(c2)
        c2 = self.conv7x1(c2)
        c2 = self.relu(c2)

        cat = torch.cat([c1, c2], dim=1)
        linear = self.linear(cat)
        out = linear

        out = self.relu(out)
        return out


# class Redution_1(nn.Module):
#     def __init__(self, input):
#         super(Redution_1, self).__init__()
#
#         self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
#
#         self.conv1 = conv1x1(in_planes=input, out_channels=256, stride=1, padding=1)
#         self.conv2 = conv3x3(in_planes=256, out_channels=384, stride=2, padding=0)
#
#         self.conv3 = conv1x1(in_planes=input, out_channels=256, stride=1, padding=1)
#         self.conv4 = conv3x3(in_planes=256, out_channels=288, stride=2, padding=0)
#
#         self.conv5 = conv1x1(in_planes=input, out_channels=256, stride=1, padding=1)
#         self.conv6 = conv3x3(in_planes=256, out_channels=288, stride=1, padding=1)
#         self.conv7 = conv3x3(in_planes=288, out_channels=320, stride=2, padding=0)
#
#     def forward(self, x):
#         c1 = self.maxpool(x)
#
#         c2 = self.conv1(x)
#         c2 = self.conv2(c2)
#
#         c3 = self.conv3(x)
#         c3 = self.conv4(c3)
#
#         c4 = self.conv5(x)
#         c4 = self.conv6(c4)
#         c4 = self.conv7(c4)
#
#         cat = torch.cat((c1, c2, c3, c4), dim=1)
#
#         return cat


class Redution_1(nn.Module):
    def __init__(self, input):
        super(Redution_1, self).__init__()
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.conv1 = conv1x1(in_planes=input,  out_channels=256, padding=1)
        self.conv2 = conv3x3(in_planes=256,  out_channels=288, stride=2, padding=0)
        self.conv3 = conv3x3(in_planes=256,  out_channels=288, stride=2, padding=0)
        self.conv4 = conv3x3(in_planes=256,  out_channels=288,  padding=1)
        self.conv5 = conv3x3(in_planes=288,  out_channels=320, stride=2, padding=0)
    def forward(self, x):
        c1 = self.maxpool(x)

        c2 = self.conv1(x)
        # print("c2", c2.shape)
        c3 = self.conv1(x)
        # print("c3", c3.shape)
        c4 = self.conv1(x)
        # print("c4", c4.shape)
        c2_1 = self.conv2(c2)
        # print("cc2_1", c2_1.shape)
        c3_1 = self.conv3(c3)
        # print("c3_1", c3_1.shape)
        c4_1 = self.conv4(c4)
        # print("c4_1", c4_1.shape)
        c4_2 = self.conv5(c4_1)
        cat = torch.cat([c1, c2_1, c3_1, c4_2], dim=1)
        # print("cat", cat.shape)
        return cat


class block2(nn.Module):
    def __init__(self, input, scale=0.3):
        super(block2, self).__init__()
        self.conv1 = conv1x1(in_planes=input, out_channels=192, stride=1, padding=0)

        self.conv2 = conv1x1(in_planes=input, out_channels=192, stride=1, padding=0)
        self.conv1x3 = nn.Conv2d(in_channels=192, out_channels=224, kernel_size=(1, 3), padding=(0, 1))
        self.conv3x1 = nn.Conv2d(in_channels=224, out_channels=256, kernel_size=(3, 1), padding=(1, 0))

        self.linear = nn.Conv2d(448, 2048, 1, stride=1, padding=0, bias=True)
        self.scale = scale
        self.relu = nn.ReLU()
        self.attention1 = cbam_block(192)
        self.attention2 = cbam_block(256)
        self.attention3 = cbam_block(2048)

    def forward(self, x):
        c1 = self.conv1(x)
        c1 = self.attention1(c1)

        c2 = self.conv2(x)
        c2 = self.conv1x3(c2)
        c2 = self.relu(c2)
        c2 = self.conv3x1(c2)
        c2 = self.relu(c2)
        c2 = self.attention2(c2)

        cat = torch.cat([c1, c2], dim=1)
        linear = self.linear(cat)
        linear = self.attention3(linear)
        out = self.scale*x + linear

        out = self.relu(out)
        return out


class Base_model(nn.Module):
    def __init__(self, classes=128):
        super(Base_model, self).__init__()
        blocks = []
        blocks.append(stem())
        for _ in range(5):
            blocks.append(block0(input=384))
        blocks.append(Redution_0(input=384))
        for _ in range(7):
            blocks.append(block1(input=1152))
        blocks.append(Redution_1(input=1152))
        for _ in range(3):
            blocks.append(block2(input=2048))

        self.features = nn.Sequential(*blocks)

        self.avepool = nn.AvgPool2d(kernel_size=3)

        self.dropout = nn.Dropout(p=0.2)
        self.fc = nn.Sequential(nn.Linear(32768, 1024), nn.ReLU(), nn.Linear(1024, classes))
        # self.fc = nn.Linear(32768, classes)

    def forward(self, x):
        x = self.features(x)
        x = self.avepool(x)
        x = self.dropout(x)
        # x = torch.flatten(x, 1)
        x = x.view(x.size(0), -1)
        # print(x.size())
        x = self.fc(x)

        return x


#CBAM 通道+空间
class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=8):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class cbam_block(nn.Module):
    def __init__(self, channel, ratio=8, kernel_size=7):
        super(cbam_block, self).__init__()
        self.channelattention = ChannelAttention(channel, ratio=ratio)
        self.spatialattention = SpatialAttention(kernel_size=kernel_size)

    def forward(self, x):
        x = x * self.channelattention(x)
        x = x * self.spatialattention(x)
        return x