import argparse

parser = argparse.ArgumentParser()


parser.add_argument('--data', metavar='DIR', default='/root/used_dataset/archive',
                    help='path to dataset')
parser.add_argument('-j', '--workers', default=32, type=int, metavar='N',
                    help='number of data loading workers (default: 32)')
parser.add_argument('--epochs', default=100, type=int, metavar='N',
                    help='number of total epochs to run')
parser.add_argument('--start-epoch', default=0, type=int, metavar='N')
parser.add_argument('-b', '--batch-size', default=32, type=int,
                    metavar='N')
parser.add_argument('--lr', '--learning-rate', default=0.0003, type=float,
                    metavar='LR', help='initial learning rate', dest='lr')
parser.add_argument('--momentum', default=0.9, type=float, metavar='M',
                    help='momentum of SGD solver')
parser.add_argument('--wd', '--weight-decay', default=1e-4, type=float,
                    metavar='W', help='weight decay (default: 1e-4)',
                    dest='weight_decay')
parser.add_argument('--pre', default='/root/autodl-tmp/checkpoints_pre/checkpoint_0199.pth.tar', type=str, metavar='PATH',
                    help='path to checkpoint_pre')
parser.add_argument('--resume', default='/root/autodl-tmp/checkpoints_targeted/checkpoint_0029.pth.tar', type=str, metavar='PATH',
                    help='path to checkpoint')
parser.add_argument('--gpu', default=0, type=int,
                    help='GPU id to use.')
parser.add_argument('--save_path',  default='/root/autodl-tmp/checkpoints_targeted',
                    help='path to save checkpoint')

# moco specific configs:
parser.add_argument('--moco-dim', default=128, type=int,
                    help='feature dimension (default: 128)')
parser.add_argument('--moco-k', default=65536, type=int,
                    help='queue size; number of negative keys (default: 65536)')
parser.add_argument('--moco-m', default=0.999, type=float,
                    help='moco momentum of updating key encoder (default: 0.999)')
parser.add_argument('--moco-t', default=0.07, type=float,
                    help='softmax temperature (default: 0.07)')

args = parser.parse_args()