import os
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.optim
import torch.utils.data
import torch.utils.data.distributed
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torch.backends.cudnn as cudnn
from tqdm import tqdm
import code_pre.model.self_supervised as make_model
import code_pre.model.model as net
from args import args
from utils import TwoCropsTransform, GaussianBlur, save_checkpoint, AverageMeter, accuracy

# COVID-19 CT上进行自监督训练
def main():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print("using {} device.".format(device))
    # 创建model
    base_model = net.Base_model
    model = make_model.MoCo(
        base_model, args.moco_dim, args.moco_k, args.moco_m, args.moco_t)
    print(model)
    for name, parms in model.named_parameters():
        print('-->name:', name, '-->grad_requirs:', parms.requires_grad)
    torch.cuda.set_device(args.gpu)
    model = model.cuda(args.gpu)
    # 定义criterion和optimizer
    criterion = nn.CrossEntropyLoss().cuda(args.gpu)
    optimizer = torch.optim.SGD(model.parameters(), args.lr,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)
    # 加载预训练模型
    if args.resume:
        print("=> loading checkpoint '{}'".format(args.resume))
        loc = 'cuda:{}'.format(args.gpu)
        checkpoint = torch.load(args.resume, map_location=loc)
        args.start_epoch = checkpoint['epoch']
        model.load_state_dict(checkpoint['state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        print("=> loaded checkpoint '{}' (epoch {})"
              .format(args.resume, checkpoint['epoch']))
    else:
        print("=> loading checkpoint '{}'".format(args.pre))
        loc = 'cuda:{}'.format(args.gpu)
        checkpoint = torch.load(args.pre, map_location=loc)
        model.load_state_dict(checkpoint['state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer'])
        print("=> loaded checkpoint '{}'".format(args.resume))

    # 增加运行效率
    cudnn.benchmark = True

    # 加载数据
    traindir = args.data
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])

    augmentation = [
        transforms.RandomResizedCrop(224, scale=(0.2, 1.)),
        transforms.RandomApply([
            transforms.ColorJitter(0.4, 0.4, 0.4, 0.1)  # not strengthened
        ], p=0.8),
        transforms.RandomGrayscale(p=0.2),
        transforms.RandomApply([GaussianBlur([.1, 2.])], p=0.5),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize
    ]

    train_dataset = datasets.ImageFolder(
        traindir,
        TwoCropsTransform(transforms.Compose(augmentation)))

    train_sampler = None

    train_loader = torch.utils.data.DataLoader(
        train_dataset, batch_size=args.batch_size, shuffle=(train_sampler is None),
        num_workers=args.workers, pin_memory=True, sampler=train_sampler, drop_last=True)

    for epoch in range(args.start_epoch, args.epochs):
        print('\nEpoch: [%d | %d] LR: %.8f' % (epoch + 1, args.epochs, optimizer.param_groups[0]['lr']))
        # train for one epoch
        train(train_loader, model, criterion, optimizer, args)

        save_checkpoint({
            'epoch': epoch + 1,
            'state_dict': model.state_dict(),
            'optimizer': optimizer.state_dict(),
        }, is_best=False, filename=os.path.join(args.save_path, 'checkpoint_{:04d}.pth.tar'.format(epoch)))


def train(train_loader, model, criterion, optimizer, args):
    losses = AverageMeter('Loss', ':.4e')
    top1 = AverageMeter('Acc@1', ':6.2f')
    top5 = AverageMeter('Acc@5', ':6.2f')
    # switch to train mode
    model.train()
    for images, _ in tqdm(train_loader):
        images[0] = images[0].cuda(args.gpu, non_blocking=True)
        images[1] = images[1].cuda(args.gpu, non_blocking=True)

        # compute output
        output, target = model(im_q=images[0], im_k=images[1])
        loss = criterion(output, target)

        # acc1/acc5 are (K+1)-way contrast classifier accuracy
        # measure accuracy and record loss
        acc1, acc5 = accuracy(output, target, topk=(1, 5))
        losses.update(loss.item(), images[0].size(0))
        top1.update(acc1[0], images[0].size(0))
        top5.update(acc5[0], images[0].size(0))

        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    print(">>>[{}] loss:{:.4f} top1:{:.4f} top5:{:.4f}".format("train", losses.avg, top1.avg, top5.avg))


if __name__ == '__main__':
    main()