import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.utils.data
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from utils import save_checkpoint, sanity_check, AverageMeter, adjust_learning_rate, accuracy
import os
from tqdm import tqdm
from args import args
from code_pre.model.model import Base_model
from sklearn import metrics

best_acc = 0

# 迁移到下游任务


def main():
    global best_acc

    if args.gpu is not None:
        print("Use GPU: {} for training".format(args.gpu))

    model = Base_model()
    # for name, parms in model.named_parameters():
    #     parms.requires_grad = False
    model.fc = nn.Linear(32768, 2)
    model.fc.weight.data.normal_(mean=0.0, std=0.01)
    model.fc.bias.data.zero_()
    print(model)
    for name, parms in model.named_parameters():
        print('-->name:', name, '-->grad_requirs:', parms.requires_grad)
    if args.targeted:
        if os.path.isfile(args.targeted):
            print("=> loading checkpoint '{}'".format(args.targeted))
            checkpoint = torch.load(args.targeted, map_location="cpu")

            # rename moco pre-trained keys
            state_dict = checkpoint['state_dict']
            for k in list(state_dict.keys()):
                # retain only encoder_q up to before the embedding layer
                if k.startswith('encoder_q') and not k.startswith('encoder_q.fc'):
                    # remove prefix
                    state_dict[k[len("encoder_q."):]] = state_dict[k]
                # delete renamed or unused k
                del state_dict[k]

            args.start_epoch = 0
            msg = model.load_state_dict(state_dict, strict=False)
            print(msg.missing_keys)
            # assert set(msg.missing_keys) == {"fc.weight", "fc.bias"}
            assert set(msg.missing_keys) == {'fc.weight', 'fc.bias'}

            print("=> loaded targeted model '{}'".format(args.targeted))
        else:
            print("=> no checkpoint found at '{}'".format(args.targeted))

    torch.cuda.set_device(args.gpu)
    model = model.cuda(args.gpu)
    # define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().cuda(args.gpu)
    parameters = list(filter(lambda p: p.requires_grad, model.parameters()))
    #assert len(parameters) == 2  # fc.weight, fc.bias
    optimizer = torch.optim.SGD(parameters, args.lr,
                                momentum=args.momentum,
                                weight_decay=args.weight_decay)
    #加快运行效率
    cudnn.benchmark = True

    # scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.2, patience=5, verbose=False)
    #数据集加载
    traindir = os.path.join(args.data, 'train')
    valdir = os.path.join(args.data, 'val')
    #数据集的处理
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])
    train_dataset = datasets.ImageFolder(
        traindir,
        transforms.Compose([
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            normalize,
        ]))

    val_dataest = datasets.ImageFolder(
        valdir,
        transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            normalize,
        ]))

    train_sampler = None

    train_loader = torch.utils.data.DataLoader(
        train_dataset, batch_size=args.batch_size, shuffle=(train_sampler is None),
        num_workers=args.workers, pin_memory=True, sampler=train_sampler)

    val_loader = torch.utils.data.DataLoader(val_dataest, batch_size=args.batch_size, shuffle=False,
        num_workers=args.workers, pin_memory=True)

    if args.evaluate:
        val(val_loader, model, criterion, args)
        return

    for epoch in range(args.start_epoch, args.epochs):
        print('\nEpoch: [%d | %d] LR: %.8f' % (epoch + 1, args.epochs, optimizer.param_groups[0]['lr']))
        adjust_learning_rate(optimizer, epoch, args)

        # train for one epoch
        train(train_loader, model, criterion, optimizer,  args)

        # evaluate on validation set
        acc1, test_loss = val(val_loader, model, criterion, args)
        # scheduler.step(test_loss)
        # remember best acc@1 and save checkpoint
        is_best = acc1 > best_acc
        best_acc = max(acc1, best_acc)

        save_checkpoint({
            'epoch': epoch + 1,
            'state_dict': model.state_dict(),
            'best_acc': best_acc,
            'optimizer': optimizer.state_dict(),
        }, is_best, filename=os.path.join(args.save_path, 'checkpoint_{:04d}.pth.tar'.format(epoch)))
        # if epoch == args.start_epoch:
        #     sanity_check(model.state_dict(), args.targeted)


def train(train_loader, model, criterion, optimizer, args):
    losses = AverageMeter('Loss', ':.4e')
    top1 = AverageMeter('Acc@1', ':6.2f')

    model.train()

    for images, target in tqdm(train_loader):
        images = images.cuda(args.gpu, non_blocking=True)
        target = target.cuda(args.gpu, non_blocking=True)

        output = model(images)
        loss = criterion(output, target)
        acc1, acc2 = accuracy(output, target, topk=(1, 2))
        losses.update(loss.item(), images.size(0))
        top1.update(acc1[0], images.size(0))

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    print(">>>[{}] train_loss:{:.4f} acc:{:.4f} ".format("train", losses.avg, top1.avg))


def val(val_loader, model, criterion, args):
    losses = AverageMeter('Loss', ':.4e')
    top1 = AverageMeter('Acc@1', ':6.2f')

    # switch to evaluate mode
    model.eval()

    with torch.no_grad():
        for i, (images, target) in enumerate(val_loader):
            images = images.cuda(args.gpu, non_blocking=True)
            target = target.cuda(args.gpu, non_blocking=True)

            # compute output
            output = model(images)
            loss = criterion(output, target)

            # measure accuracy and record loss
            acc1, acc2 = accuracy(output, target, topk=(1, 2))
            losses.update(loss.item(), images.size(0))
            top1.update(acc1[0], images.size(0))
            # measure elapsed time
    print(">>>[{}] val_loss:{:.4f} acc:{:.4f} ".format("val", losses.avg, top1.avg))
    return top1.avg, losses.avg


def test():
    model = Base_model()
    model.fc = nn.Linear(32768, 2)
    checkpoint = torch.load(args.model_path, map_location="cpu")
    state_dict = checkpoint['state_dict']
    model.load_state_dict(state_dict)
    model = model.cuda()
    testdir = os.path.join(args.data, 'test')
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])
    test_loader = torch.utils.data.DataLoader(
        datasets.ImageFolder(testdir, transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            normalize,
        ])),
        batch_size=args.batch_size, shuffle=False,
        num_workers=args.workers, pin_memory=True)
    y_pred = []
    y_true = []
    with torch.no_grad():
        model.eval()
        for (inputs, targets) in tqdm(test_loader):
            y_true.extend(targets.detach().tolist())
            inputs, targets = inputs.cuda(), targets.cuda()
            inputs, targets = torch.autograd.Variable(inputs), torch.autograd.Variable(targets)
            outputs = model(inputs)  # (16,2)
            # dim=1 表示按行计算 即对每一行进行softmax
            # probability = torch.nn.functional.softmax(outputs,dim=1)[:,1].tolist()
            # probability = [1 if prob >= 0.5 else 0 for prob in probability]
            probability = torch.max(outputs, dim=1)[1].data.cpu().numpy().squeeze()
            y_pred.extend(probability)
        print("y_pred=", y_pred)
        print('y_true=', y_true)

        accuracy = metrics.accuracy_score(y_true, y_pred)
        confusion_matrix = metrics.confusion_matrix(y_true, y_pred)
        print("confusion_matrix=", confusion_matrix)
        print(metrics.classification_report(y_true, y_pred))
        print("accuracy=", accuracy)
        print("roc-auc score=", metrics.roc_auc_score(y_true, y_pred))
        print("f1-score=", metrics.f1_score(y_true, y_pred))
        print("precision=", metrics.precision_score(y_true, y_pred))

if __name__ == '__main__':
    if args.mode == 'train':
        main()
    else:
        test()