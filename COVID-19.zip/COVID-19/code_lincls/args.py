import argparse


parser = argparse.ArgumentParser()
parser.add_argument('--mode', type=str, required=True)
parser.add_argument('--data', metavar='DIR', default='/root/used_dataset/lincls',
                    help='path to dataset')
parser.add_argument('-j', '--workers', default=15, type=int, metavar='N',
                    help='number of data loading workers (default: 32)')
parser.add_argument('--epochs', default=200, type=int, metavar='N',
                    help='number of total epochs to run')
parser.add_argument('--start-epoch', default=0, type=int, metavar='N',
                    help='manual epoch number (useful on restarts)')
parser.add_argument('-b', '--batch-size', default=32, type=int,
                    metavar='N')
# parser.add_argument('--lr', '--learning-rate', default=30., type=float,
#                     metavar='LR', help='initial learning rate', dest='lr')
# parser.add_argument('--schedule', default=[60, 80], nargs='*', type=int,
#                     help='learning rate schedule (when to drop lr by a ratio)')

parser.add_argument('--lr', '--learning-rate', default=0.03, type=float,
                    metavar='LR', help='initial learning rate', dest='lr')
parser.add_argument('--schedule', default=[120, 160], nargs='*', type=int,
                    help='learning rate schedule (when to drop lr by 10x)')

parser.add_argument('--momentum', default=0.9, type=float, metavar='M',
                    help='momentum')
parser.add_argument('--wd', '--weight-decay', default=0., type=float,
                    metavar='W', help='weight decay (default: 0.)',
                    dest='weight_decay')
parser.add_argument('--resume', default='', type=str, metavar='PATH',
                    help='path to latest checkpoint (default: none)')
parser.add_argument('-e', '--evaluate', dest='evaluate', action='store_true',
                    help='evaluate model on validation set')
parser.add_argument('--gpu', default=0, type=int,
                    help='GPU id to use.')


parser.add_argument('--targeted', default='/root/autodl-tmp/cp_tar/checkpoint_0099.pth.tar', type=str,
                    help='path to targeted pretrained checkpoint')
# parser.add_argument('--resume', default='/root/code_lincls/model_best04.pth.tar', type=str,
#                     help='path to targeted pretrained checkpoint')
parser.add_argument('--save_path',  default='/root/autodl-tmp/cp_lin2',
                    help='path to save checkpoint')
parser.add_argument('--model_path', default='/root/autodl-tmp/cp_latest/cp_lin2.pth.tar', type=str)
args = parser.parse_args()

# 00 pre+tar=lin  02 pre+lin 03 新数据集 1.lr 04 2.lr
# 06 200epoch
# 07 全部训练